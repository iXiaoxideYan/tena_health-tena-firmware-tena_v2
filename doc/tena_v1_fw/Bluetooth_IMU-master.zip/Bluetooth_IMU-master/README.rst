================= =====
Supported Targets ESP32
================= =====

BT_IMU_2_0
======================

Firmware and PCB design of an IMU sensor board to be used with stroke rehabilitation and data collection.
